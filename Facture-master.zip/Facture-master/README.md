Facture
-------
Web app written in Python and [Flask](http://flask.pocoo.org/) to quickly generate invoices. 

### Why? 

My goal was to learn Flask framework. 

And of course, use this app to generate invoices for our school photo club @[ClubReflets](https://github.com/ClubReflets)
